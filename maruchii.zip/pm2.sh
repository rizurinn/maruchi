#!/bin/bash
source .venv/bin/activate
bun start
